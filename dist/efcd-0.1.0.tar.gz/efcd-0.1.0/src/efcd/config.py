DEFAULT_SAMPLE_ROWS = 10000
DEFAULT_OUT_DIR = "data"

DEFAULT_THRESHOLDS = {
    "null_rate_delta": 0.10,
    "distinct_ratio": 2.0,
    "mean_std_multiplier": 3.0,
    "row_count_delta": 0.20,
}
